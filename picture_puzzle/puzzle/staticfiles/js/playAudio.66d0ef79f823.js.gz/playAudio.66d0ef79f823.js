function play_audio() {
    // let x = document.getElementById('playSound');
    // x.play();
    // $("#playSound").play();
    let audio = new Audio('/static/audio/Directed_by_Robert_B_Weide_theme_meme_audio.mp3')
    audio.play();
}